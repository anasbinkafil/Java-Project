---
name: Clinical Integrity
colors:
  surface: '#f7fafc'
  surface-dim: '#d7dadc'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#ebeef0'
  surface-container-high: '#e5e9eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#5a403e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f3'
  outline: '#8e706d'
  outline-variant: '#e2bebb'
  surface-tint: '#b52426'
  primary: '#a2141b'
  on-primary: '#ffffff'
  primary-container: '#c53030'
  on-primary-container: '#ffe4e1'
  inverse-primary: '#ffb3ad'
  secondary: '#13696a'
  on-secondary: '#ffffff'
  secondary-container: '#a2eded'
  on-secondary-container: '#1a6d6e'
  tertiary: '#005293'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a6baf'
  on-tertiary-container: '#dfeaff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#920212'
  secondary-fixed: '#a5eff0'
  secondary-fixed-dim: '#89d3d4'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f50'
  tertiary-fixed: '#d3e4ff'
  tertiary-fixed-dim: '#a2c9ff'
  on-tertiary-fixed: '#001c38'
  on-tertiary-fixed-variant: '#004881'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
---

## Brand & Style

The design system focuses on precision, reliability, and clinical trust. It is designed for healthcare professionals who manage critical, life-saving data. The aesthetic balances a "Corporate Modern" foundation with "Minimalist" clarity to ensure that high-density medical information is processed without cognitive fatigue.

The emotional response should be one of institutional stability and urgent efficiency. To achieve this, the system utilizes high-quality typography, generous white space, and a disciplined color application that prioritizes function over decoration.

## Colors

This system uses a "Clinical White" palette. Surfaces are primarily white or very light gray to emulate the sterility and clarity of a medical environment.

- **Primary (Blood Red):** Used exclusively for critical branding, urgent calls to action, and blood-type indicators.
- **Secondary (Teal):** Used for success states, completed donor registrations, and "safe" inventory levels.
- **Tertiary (Blue):** Used for informational accents and secondary navigation elements to provide a calming counterpoint to the primary red.
- **Neutral:** A range of cool grays used for borders, subtle backgrounds, and secondary text to maintain a high-contrast, professional structure.

## Typography

The design system employs **Inter** across all levels. This typeface was selected for its exceptional legibility in data-heavy contexts and its neutral, systematic character.

- **Headlines:** Use tighter letter spacing and heavier weights to establish a clear hierarchy.
- **Data Tables:** Use `body-sm` for tabular data to maximize information density while maintaining readability.
- **Labels:** Use `label-md` with all-caps and increased letter spacing for form headers and metadata categories.
- **Mobile:** Large display titles scale down to `headline-lg-mobile` to prevent awkward wrapping on handheld devices used by floor staff.

## Layout & Spacing

This design system follows a **Fixed Grid** model for desktop to ensure data visualizations and tables remain consistent and legible. 

- **Grid:** A 12-column grid is used for desktop layouts.
- **Rhythm:** An 8px linear scale governs all padding and margins (8, 16, 24, 32, 40, 48, 64).
- **Desktop:** 40px outer margins with 24px gutters.
- **Tablet:** 8-column grid with 24px margins.
- **Mobile:** 4-column fluid grid with 16px margins. 

Layouts should prioritize vertical stacking for forms and use horizontal scrolling or "cards" for data tables on smaller viewports.

## Elevation & Depth

To maintain a "flat, modern" clinical feel, depth is expressed through **Tonal Layering** supplemented by **Ambient Shadows**.

- **Level 0 (Background):** Neutral light gray (#F7FAFC).
- **Level 1 (Cards/Surface):** Pure White (#FFFFFF) with a 1px border in a soft gray (#E2E8F0).
- **Level 2 (Active/Hover):** A very soft, diffused shadow (0px 4px 6px rgba(0, 0, 0, 0.05)) to indicate interactivity.
- **Level 3 (Modals):** A more pronounced shadow (0px 10px 15px rgba(0, 0, 0, 0.1)) to focus attention on critical actions like "Confirm Transfusion."

Avoid heavy blurs or colorful glows; keep the elevation feeling structural and grounded.

## Shapes

The shape language is professional and "Soft-Geometric." 

- **Standard Elements:** Buttons, Input fields, and Cards use a 0.5rem (8px) radius. This provides a modern, approachable feel without appearing overly casual.
- **Large Containers:** Dashboard sections or large modal overlays use a 1rem (16px) radius.
- **System Tags:** Blood group badges and status indicators (e.g., "Available", "Low Stock") may use pill-shaped (full-round) corners to distinguish them from actionable buttons.

## Components

- **Buttons:** Primary buttons use the Primary Red background with white text. Secondary buttons use a white background with a gray border. Use 16px vertical padding for a substantial "touch target" feel.
- **Input Fields:** Use 1px solid gray borders that thicken and turn Blue (Tertiary) on focus. Labels must always be visible (no floating labels) to ensure clarity during fast data entry.
- **Data Tables:** Essential for inventory. Use a white background, subtle gray dividers, and a sticky header. Alternate row striping is recommended for high-density lists.
- **Status Chips:** Small, rounded indicators. Use Teal for "In Stock," Red for "Critical/Urgent," and Amber for "Expiring Soon."
- **Progress Steppers:** Used for donor registration workflows. Use a clean line-and-dot system to indicate the current phase of the medical interview.
- **Cards:** Used for high-level dashboard stats (e.g., "Total Units Collected"). Cards should be white with a 1px border and a simple icon in the Tertiary color.